// *** Hardwarespecific defines ***
//#define cbi(reg, bitmask) *reg &= ~bitmask
//#define sbi(reg, bitmask) *reg |= bitmask
#define pulseClock digitalWriteFast(SCK_Pin,LOW); asm ("nop"); digitalWriteFast(SCK_Pin,HIGH)
#define resetLCD digitalWrite(DC_Pin,HIGH); digitalWrite(MOSI_Pin,HIGH); digitalWrite(SCK_Pin,HIGH); digitalWrite(CS_Pin,HIGH); digitalWrite(RST_Pin, LOW); digitalWrite(RST_Pin, HIGH)

#define fontbyte(x) cfont.font[x]  
#define bitmapbyte(x) bitmap[x]

#define regtype volatile uint32_t
#define regsize volatile uint32_t
#define bitmapdatatype unsigned char*
